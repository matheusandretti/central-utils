// content.js

console.log("[Consulta NFe Helper] content.js carregado");

const CONSULTA_BASE =
  "https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx";
const RESUMO_BASE =
  "https://www.nfe.fazenda.gov.br/portal/consultaResumo.aspx";

function estaNaTelaDeConsulta() {
  return (
    location.href.startsWith(CONSULTA_BASE) ||
    location.href.includes("consultaRecaptcha.aspx")
  );
}

function estaNaTelaDeResumo() {
  return (
    location.href.startsWith(RESUMO_BASE) ||
    location.href.includes("consultaResumo.aspx")
  );
}

// ================================
// Painel flutuante
// ================================
function createFloatingPanel() {
  if (document.getElementById("nfe-helper-panel")) return;

  const panel = document.createElement("div");
  panel.id = "nfe-helper-panel";
  panel.style.position = "fixed";
  panel.style.bottom = "20px";
  panel.style.right = "20px";
  panel.style.zIndex = "999999";
  panel.style.background = "rgba(0,0,0,0.8)";
  panel.style.color = "#fff";
  panel.style.padding = "10px 14px";
  panel.style.borderRadius = "8px";
  panel.style.fontFamily = "sans-serif";
  panel.style.fontSize = "12px";
  panel.style.boxShadow = "0 2px 10px rgba(0,0,0,0.3)";

  const title = document.createElement("div");
  title.textContent = "Consulta NFe Helper";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "4px";

  const info = document.createElement("div");
  info.id = "nfe-helper-info";
  info.textContent =
    "Fluxo: Pegar chave → você resolve captcha → Continuar → Download auto.";

  const keySpan = document.createElement("div");
  keySpan.id = "nfe-helper-key";
  keySpan.style.marginTop = "4px";
  keySpan.style.fontFamily = "monospace";

  const btn = document.createElement("button");
  btn.textContent = "Pegar próxima chave";
  btn.style.marginTop = "6px";
  btn.style.padding = "4px 8px";
  btn.style.borderRadius = "4px";
  btn.style.border = "none";
  btn.style.cursor = "pointer";

  btn.addEventListener("click", async () => {
    info.textContent = "Buscando próxima chave...";
    keySpan.textContent = "";

    const result = await requestNextKey();
    if (!result.ok) {
      info.textContent = "Erro ao buscar chave (veja console).";
      console.error(result.error);
      return;
    }
    if (!result.key) {
      info.textContent = "Fila vazia (sem chaves).";
      return;
    }

    keySpan.textContent = result.key;

    try {
      await chrome.storage.local.set({ pendingKey: result.key });
    } catch (e) {
      console.warn("[Consulta NFe Helper] Erro ao gravar pendingKey:", e);
    }

    if (estaNaTelaDeConsulta()) {
      preencherCampoDaChave(result.key);
      info.textContent = "Chave preenchida na tela de consulta.";
    } else {
      info.textContent = "Indo para tela de consulta...";
      window.location.href =
        CONSULTA_BASE + "?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=";
    }
  });

  panel.appendChild(title);
  panel.appendChild(info);
  panel.appendChild(keySpan);
  panel.appendChild(btn);

  document.body.appendChild(panel);
}

function requestNextKey() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "GET_NEXT_KEY" }, (response) => {
      if (!response) {
        return resolve({
          ok: false,
          error: "Sem resposta do background.",
        });
      }
      resolve(response);
    });
  });
}

function preencherCampoDaChave(key) {
  if (!key) return;

  let input = null;

  // tenta localizar pelo texto do rótulo
  const labels = Array.from(document.querySelectorAll("label"));
  const alvo = labels.find((lbl) =>
    (lbl.innerText || "")
      .toLowerCase()
      .includes("chave de acesso da nf-e")
  );

  if (alvo) {
    const forId = alvo.getAttribute("for");
    if (forId) {
      input = document.getElementById(forId);
    }
  }

  // fallback por id
  if (!input) {
    input =
      document.querySelector('input[id$="txtChaveAcesso"]') ||
      document.querySelector('input[id*="txtChaveAcesso"]');
  }

  if (!input) {
    console.warn(
      "[Consulta NFe Helper] Campo de chave não encontrado na página."
    );
    return;
  }

  input.value = key;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));

  console.log("[Consulta NFe Helper] Chave preenchida:", key);
}

async function aplicarPendingKeySeNecessario() {
  if (!estaNaTelaDeConsulta()) return;

  let key = null;
  try {
    const data = await chrome.storage.local.get(["pendingKey"]);
    key = data.pendingKey;
  } catch (e) {
    console.warn("[Consulta NFe Helper] Erro ao ler pendingKey:", e);
  }

  if (!key) return;

  preencherCampoDaChave(key);

  const info = document.getElementById("nfe-helper-info");
  const keySpan = document.getElementById("nfe-helper-key");
  if (info) info.textContent = "Chave preenchida automaticamente.";
  if (keySpan) keySpan.textContent = key;

  try {
    await chrome.storage.local.remove(["pendingKey"]);
  } catch (e) {
    console.warn("[Consulta NFe Helper] Erro ao limpar pendingKey:", e);
  }
}

// ================================
// Auto-download na tela de resumo
// ================================
function autoDownloadNaTelaResumo() {
  if (!estaNaTelaDeResumo()) return;
  if (window.__nfeHelperDownloadJaDisparado) return;
  window.__nfeHelperDownloadJaDisparado = true;

  console.log("[Consulta NFe Helper] Tela de resumo detectada, procurando botão de download...");

  // dá um tempinho pra página terminar de renderizar
  setTimeout(() => {
    // tenta pelo id exato (mais confiável)
    let botao =
      document.getElementById("ctl00_ContentPlaceHolder1_btnDownload") ||
      // fallback: qualquer input submit com nome terminando em "btnDownload"
      document.querySelector('input[type="submit"][name$="btnDownload"]') ||
      // fallback extra: input submit cujo value contenha "Download do documento"
      Array.from(document.querySelectorAll('input[type="submit"]')).find((el) =>
        (el.value || "").toLowerCase().includes("download do documento")
      );

    if (!botao) {
      console.warn(
        "[Consulta NFe Helper] Não achei o botão 'Download do documento*' na tela de resumo."
      );
      return;
    }

    console.log(
      "[Consulta NFe Helper] Clicando no botão de download:",
      botao.id || botao.name || botao.value
    );

    botao.click(); // isso vai disparar o confirm() do site; você ainda clica em "OK"
  }, 1000);
}


// ================================
// Mensagens vindas do background
// ================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "NAVIGATE_TO_CONSULTA") {
    if (estaNaTelaDeConsulta()) {
      aplicarPendingKeySeNecessario().catch((err) =>
        console.error("[Consulta NFe Helper] Erro ao aplicar pendingKey:", err)
      );
    } else {
      window.location.href =
        CONSULTA_BASE + "?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=";
    }
  }
});

// ================================
// init
// ================================
function init() {
  if (!location.href.includes("nfe.fazenda.gov.br/portal/")) return;

  createFloatingPanel();

  // se já tiver chave pendente e estivermos na tela de consulta, preenche
  aplicarPendingKeySeNecessario().catch((err) =>
    console.error("[Consulta NFe Helper] Erro ao aplicar pendingKey no init:", err)
  );

  // se estivermos na tela de resumo (após você clicar Continuar), disparar download automático
  autoDownloadNaTelaResumo();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
