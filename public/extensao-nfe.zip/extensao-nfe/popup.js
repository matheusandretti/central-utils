// popup.js

document.getElementById("test-backend").addEventListener("click", () => {
  const status = document.getElementById("status");
  status.textContent = "Testando conexão com http://localhost:3000 ...";

  fetch("http://localhost:3000/api/ping")
    .then((res) => res.text())
    .then((txt) => {
      status.textContent = "Backend respondeu: " + txt;
    })
    .catch((err) => {
      console.error(err);
      status.textContent = "Erro ao conectar no backend: " + String(err);
    });
});
