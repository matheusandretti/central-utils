// polyfill.js
if (typeof browser === "undefined") {
  window.browser = chrome;
}
