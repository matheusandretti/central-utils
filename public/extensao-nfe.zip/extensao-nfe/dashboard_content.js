// dashboard_content.js
console.log("[NFe Helper] dashboard_content.js carregado em", location.href);

// Escuta mensagens vindas da própria página (window.postMessage)
window.addEventListener("message", (event) => {
    // Segurança básica: só responde a mensagens da mesma janela
    if (event.source !== window) return;

    const data = event.data;
    if (!data || data.type !== "NFE_HELPER_PING") return;

    // Responde dizendo que a extensão está presente
    window.postMessage({ type: "NFE_HELPER_PONG" }, "*");
});
