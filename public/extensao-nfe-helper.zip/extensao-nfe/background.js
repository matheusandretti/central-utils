// background.js

const BACKEND_BASE = "http://192.0.0.78:3000";

let lastKey = null; // última chave entregue pelo backend

// =========================
// Comunicação com content.js
// =========================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_NEXT_KEY") {
    fetchNextKey()
      .then((key) => {
        if (key) lastKey = key;
        sendResponse({ ok: true, key: key || null });
      })
      .catch((err) => {
        console.error("[NFe Helper] Erro ao buscar próxima chave:", err);
        sendResponse({ ok: false, error: String(err) });
      });
    return true;
  }

  if (message.type === "MARK_DONE" && message.key) {
    marcarChaveComoConcluida(message.key)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => {
        console.error("[NFe Helper] Erro ao marcar chave como concluída:", err);
        sendResponse({ ok: false, error: String(err) });
      });
    return true;
  }
});

// =========================
// Chamadas ao backend
// =========================

async function fetchNextKey() {
  const url = `${BACKEND_BASE}/api/next-key`;
  const res = await fetch(url);

  const ct = res.headers.get("content-type") || "";
  if (!ct.includes("application/json")) {
    const txt = await res.text();
    console.error(
      "[NFe Helper] /api/next-key não retornou JSON. Trecho:",
      txt.slice(0, 200)
    );
    return null;
  }

  const data = await res.json();
  console.log("[NFe Helper] /api/next-key →", data);
  return data && data.key ? data.key : null;
}

async function marcarChaveComoConcluida(key) {
  const url = `${BACKEND_BASE}/api/mark-done`;
  console.log("[NFe Helper] /api/mark-done para chave:", key);

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key }),
  });

  if (!res.ok) {
    const txt = await res.text();
    console.error(
      `[NFe Helper] /api/mark-done HTTP ${res.status}:`,
      txt.slice(0, 200)
    );
    throw new Error(`HTTP ${res.status}`);
  }

  console.log("[NFe Helper] /api/mark-done OK para chave:", key);
}

// =========================
// Utilitários
// =========================

function extrairChaveDoNomeOuUrl(downloadItem) {
  const filename = downloadItem.filename || "";
  const url = downloadItem.url || "";

  const sources = [filename, url];
  for (const src of sources) {
    const match = String(src).match(/\d{44}/);
    if (match) return match[0];
  }
  return null;
}

async function processarDownloadEChamarProxima(keyDoDownload) {
  if (!keyDoDownload) {
    console.warn("[NFe Helper] processarDownloadEChamarProxima sem chave.");
    return;
  }

  // 1) tenta marcar como concluída, mas se der erro continua mesmo assim
  try {
    await marcarChaveComoConcluida(keyDoDownload);
  } catch (err) {
    console.error(
      "[NFe Helper] Falha ao marcar chave concluída, vou assim mesmo para próxima:",
      err
    );
  }

  // 2) pega próxima chave
  const nextKey = await fetchNextKey();
  if (!nextKey) {
    console.log(
      "[NFe Helper] Não há próxima chave na fila após download da chave:",
      keyDoDownload
    );
    return;
  }

  lastKey = nextKey;
  console.log("[NFe Helper] Próxima chave após download:", nextKey);

  await chrome.storage.local.set({ pendingKey: nextKey });

  // 3) manda alguma aba do portal voltar para tela de consulta
  chrome.tabs.query(
    { url: "https://www.nfe.fazenda.gov.br/portal/*" },
    (tabs) => {
      if (!tabs || !tabs.length) {
        console.warn(
          "[NFe Helper] Nenhuma aba do portal NF-e encontrada para aplicar próxima chave."
        );
        return;
      }
      const tab = tabs[0];
      chrome.tabs.update(tab.id, { active: true }, () => {
        chrome.tabs.sendMessage(tab.id, {
          type: "NAVIGATE_TO_CONSULTA",
        });
      });
    }
  );
}

// =========================
// Listener de downloads
// =========================

chrome.downloads.onCreated.addListener((downloadItem) => {
  try {
    console.log("[NFe Helper] onCreated download:", downloadItem);

    // Se ainda não tivemos chave nenhuma, não faz nada
    if (!lastKey) {
      console.log(
        "[NFe Helper] Download detectado mas lastKey está vazio; ignorando."
      );
      return;
    }

    // tenta achar chave no nome/URL; se não achar, usa lastKey
    let key = extrairChaveDoNomeOuUrl(downloadItem);
    if (!key) {
      console.log(
        "[NFe Helper] Não achei 44 dígitos no nome/URL; usando lastKey:",
        lastKey
      );
      key = lastKey;
    }

    console.log("[NFe Helper] Download associado à chave:", key);
    processarDownloadEChamarProxima(key).catch((err) =>
      console.error("[NFe Helper] Erro no fluxo pós-download:", err)
    );
  } catch (err) {
    console.error("[NFe Helper] Erro em downloads.onCreated:", err);
  }
});
